﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DNicholsonA2_1LL
{
    public partial class frmMain : Form
    {

        LinkedList<double> numbers = new LinkedList<double>();

        public frmMain()
        {
            InitializeComponent();
        }

        private void btnGet_Click(object sender, EventArgs e)
        {
            double[] random = { 0.0, 1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8, 9.9 };

            numbers = new LinkedList<double>(random);

            foreach(double n in numbers)
            {
                lbxDisplay.Items.Add(n);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            double sum = 0.0;
            
            foreach(double n in numbers)
            {
                lbxDisplay.Items.Add(n);
                sum = sum + n; 
            }
            
            MessageBox.Show("The sum is " + sum.ToString());
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            if(numbers.Remove(0.0))
            {
                foreach (double n in numbers)
                {
                    lbxDisplay.Items.Add(n);
                }
            }
            else
            {
                MessageBox.Show("Number Not Found");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lbxDisplay.Items.Clear();
        }

        private void btnAverage_Click(object sender, EventArgs e)
        {
            double sum = 0.0;
            double average = 0.0;
            int count = 0;

            foreach (double n in numbers)
            {
                lbxDisplay.Items.Add(n);
                sum = sum + n;
                count++;
                average = sum / count;
            }



            MessageBox.Show(count.ToString());
            MessageBox.Show("The Average is " + average.ToString());
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
