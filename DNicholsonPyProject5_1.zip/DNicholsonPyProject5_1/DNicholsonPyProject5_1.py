import pyodbc

server='cstnt.tstc.edu'
database='itse2359sp21'
username='dnicholsonsp212359'
password='1673234'


con = pyodbc.connect('Driver={ODBC Driver 17 for SQL Server};SERVER='+server+
                     ';DATABASE='+database+';UID='+username+';PWD='+password)

cursor=con.cursor()
#query = cursor.execute("Select * from teachsp212359.terminology WHERE term like 'm%'")
#query = cursor.execute("Select * from teachsp212359.terminology WHERE term = 'hardware'")
#query = cursor.execute("Select * from teachsp212359.terminology WHERE term like '%s%'")
#query = cursor.execute("Select * from teachsp212359.terminology WHERE term = 'ware'")
query = cursor.execute("Select * from teachsp212359.terminology WHERE term like '%t'")

results = cursor.fetchall()
for result in results:
    print(results)

